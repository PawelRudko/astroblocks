# Astroblocks — the kit's brain (instructions for the AI agent)

This is the kit's "brain". When the user asks to change or add a section, stick to these rules
so everything stays consistent with the system — **don't make up values**, reach for the tokens below.

Works with any agent (Claude Code reads it via `CLAUDE.md`, Codex reads `AGENTS.md` directly,
Cursor/Copilot can be pointed at this file). Sections are plain `.astro` files — zero tool lock-in.

## Design tokens (use them, don't hardcode random colors)

| Token | Value | Used for |
|---|---|---|
| Background | `#FFFFFF` | main background (light theme) |
| Surface 2 | `#F5F5F3` | subtle fills |
| Text | `#21201C` | headings, copy, nav |
| Faint | `#9B9890` | eyebrows, very subtle labels |
| Line | `rgba(24,24,27,0.10)` / `0.16` | borders, dividers |
| **Main button (indigo)** | `#5B5BD6` (hover `#4E4EC8`), text `#FFF` | CTA / primary action |
| Secondary button | white bg + `line-strong` border + text `#21201C` | secondary action |
| Text accent (lavender) | `#7C6CD0` | highlighted word in a heading via `<em>` |
| Geo pastels (hero/footer) | lav `#D3C6F9` · peach `#FAC6BD` · butter `#FED888` · mint `#BEE3BF` · sky `#B4E0EA` · rose `#F3C6E2` | geometric backgrounds |
| Section "dark" variant | bg `#0A0A0C`/`#0E0E11`, lime accent `#CBF24A` | dark sections (e.g. HeroSplit dark) |

- **Radius:** buttons/inputs `12px`, cards/sections `16px`.
- **Font:** only **Inter** (`'Inter Variable'`) for headings and body; **JetBrains Mono** for eyebrows/labels/code. Don't introduce another display font unless asked.

## Typography — H1–H6 heading system (global in Layout)

All headings: **Inter, `font-weight: 600` (semibold, NOT bold), color `#21201C` (black)**.

| Tag | Size | Notes |
|---|---|---|
| **H1** | `48px` (clamp to 3rem) | hero, line-height 1.05 |
| **Section heading** | `clamp(25.6px, 2.8vw, 36.8px)` | first H1/H2 in each top-level block, line-height `1.1` |
| **H2** | `24px` (1.5rem) | internal section heading |
| **H3** | `20px` (1.25rem) | sub-heading |
| **H4** | `18px` | |
| **H5** | `16px` | |
| **H6** | `14px` | |

- Use **semantic tags** `<h1>`–`<h6>` — the style comes from the global, don't duplicate it.
- **Body/copy:** minimum `16px`, descriptive line-height `1.5`, color `#21201C`.
- **Eyebrow:** Inter, `0.72rem`, UPPERCASE, `letter-spacing: 0.16em`, color `faint`.
- Highlight in a heading = `<em>` (not italic) in lavender `#7C6CD0` (globally).

## Buttons — 3 types (global in Layout)

Size/shape like in the hero: small, `radius 12px`, `padding 0.55rem 1rem`, `weight 600`, `size 0.9rem`. `.btn--sm` = smaller.

1. **`.btn .btn--primary`** — MAIN: indigo bg `#5B5BD6`, hover `#4E4EC8`, white text.
2. **`.btn .btn--secondary`** — SECONDARY: white bg + border, hover `border-color: text` + bg `#faf9f7`. (`.btn--ghost` is an alias.)
3. **`.btn .btn--link`** — LINK: no bg/border, underlined text, no arrow.

Use at most two CTA buttons in a block. Do not add a third CTA just to demonstrate every style.

Copy buttons have a **copy icon** (`.btn__ico`) + `<span class="btn__label">…</span>` (JS swaps just the label).

## Animations (premium style, "don't overdo it")

- Section entrance: a subtle **staggered fade-up** (`translateY 18px → 0`, opacity, ~0.7s, delay per element `--d`).
- Always guard `@media (prefers-reduced-motion: reduce)` → show the final state.
- Pattern: see `HeroCentered.astro` (keyframes `hcRise` / `hcMedia`).

## Code conventions

- Each section = **one `.astro` file** in `src/components/sections/`.
- Styles always **scoped** (`<style>` in the component), **mobile-first**, breakpoint `720px`.
- Content **through props** — don't hardcode text in the markup.
- Variants: prop `variant="light" | "dark"`.
- Animations: **always** guard `@media (prefers-reduced-motion: reduce)`.
- Images: through props; demo placeholder = `/placeholder-landscape.svg`.
- **Dashes: use `–` (en-dash), NOT `—` (em-dash).**

## Images & assets — how they travel when a block is copied

The most important rule: **a block never hardcodes a photo. Images always come in through a prop**, with the component default being the self-contained placeholder (`/placeholder-landscape.svg`).

- **Demo photos** (the nice Unsplash pictures you see in the gallery) live **only in `src/data/sections.ts`** (the `demo` field), via the `u()`/`P`/`person`/`editorial` helpers. They are just external `https://images.unsplash.com/...` URLs — **no files are stored in the repo**.
- The **"Copy" button copies only the component source** (`/raw/<id>`), **not** the demo data. So a copied block carries **no photo and no dependency** — it renders the placeholder until the user passes their own `image="..."`.
- Consequence for someone who downloads the kit: **cloning the whole repo** works out of the box (demo URLs are remote). **Copy-pasting a single block** into another project gives clean code — they supply their own images. This is intentional: bring-your-own-image, zero broken asset paths.
- When you want a demo to look real in the gallery, add a **remote URL** to its `demo` in `sections.ts` — **do not** hardcode it inside the `.astro` component, and **do not** rely on a local file unless the user puts it in `public/`.

## Building the user's page — DEFAULT mode (assembling from ready-made blocks)

When someone says "add section X", "drop NavBar/Hero/FAQ onto the page", "add another block", or **pastes block code from the "Copy" button** — this is about **assembling the home page `/` from READY-MADE blocks** that already live in `src/components/sections/`. **Do NOT register anything in the gallery, do NOT create `/preview` subpages.** Do this:

1. Open **`src/pages/index.astro`** — this is the home page (the user's canvas).
2. Import the component at the top (frontmatter), e.g. `import NavBar from '../components/sections/NavBar.astro';`
3. Insert it **inside `<main>`**: `<NavBar {...props} />`. **Add further blocks BELOW** — sections stack one under another, in insertion order (like a normal web page).
4. With the first block **remove the empty canvas** (`<section class="empty">…</section>`).
5. Take props from the demo in `src/data/sections.ts` (the block's `demo` field) and adjust the text per the request.

Result: the user sees their sections at `http://localhost:4322/` — **not** at `/preview/...`. The `/preview` subpages are only gallery previews, NOT a place for the user's page.

## Finding a block the user names from the gallery ("add FEATURES 16")

Gallery cards are labelled `CATEGORY NN` — `FEATURES 16`, `HERO 03`, `NAV 01`. **Do not grep for that label: it exists in no file.** It is generated at the bottom of `src/data/sections.ts`:

```js
label: `${s.category.toUpperCase()} ${String(catCount[s.category]).padStart(2, '0')}`
```

`NN` is simply the **position of that entry among entries with the same `category`, in registry order** (1-based). So resolve it by counting, not searching:

1. `FEATURES 16` → in `src/data/sections.ts`, take the entries with `category: 'Features'` **in file order** and pick the **16th**.
2. Read its `file` (e.g. `FeatureServicesImages.astro`) and its `demo` props.
3. Import from `src/components/sections/<file>` and insert it per "Building the user's page" above.

The reliable handles are `id` and `name` (e.g. `feature-services-images` / "Feature Services Images"); the label is only a display name. If the user's label is ambiguous or out of range, **say so and show the candidates** — don't silently pick a different block. The user may also paste block code straight from the gallery's "Copy" button, which needs no lookup at all.

**Match the label loosely — the user is typing, not quoting.** All of these mean the same block and must all work:

- **Any case:** `FEATURES 05`, `Features 05`, `features 05`.
- **Padded or not:** `Hero 1` = `Hero 01` = `HERO 01`. Strip leading zeros before comparing.
- **Singular/plural or a near-miss category:** `Feature 05` → `Features`, `Navs 02` → `Nav`. Match the category case-insensitively and accept the obvious singular/plural variant.
- **Any language.** Requests come in **English or Polish** (and possibly others): *"add Hero 01"*, *"dodaj mi blok Hero 01"*, *"dodaj teraz Features 02"*, *"wstaw Features 02 pod spodem"*. The **label itself stays as-is in any language** — `Hero 01` is `Hero 01` — so parse `CATEGORY + number` out of the sentence whatever the surrounding words are. Verbs to expect: add / insert / put / drop → dodaj / wstaw / daj / umieść. "Pod spodem"/"poniżej" = below the previous block; "na górze"/"nad" = above it.
- **Categories can be two words** — `SUBPAGE HERO 03` is category `Subpage Hero`, number `03`. Take the number as the trailing digits and *everything before it* as the category; don't assume one word.
- **Reply in the language the user wrote in**, but never translate a label, `id`, `file` name or prop name.

The full category list is whatever appears in `src/data/sections.ts` — currently: Nav, Hero, Footer, Team, Blog, FAQ, Card, Tabs, Pricing, Testimonial, Logo, Event, Contact, Features, CTA, Slider, Subpage Hero, Blog Details, Table, Error, Changelog, Careers, Integrations, Gallery. Read it from the registry rather than trusting this list.

Only ask for clarification when the label genuinely doesn't resolve (wrong number, unknown category) — not because of casing, padding, plural or language.

## Adding a COMPLETELY NEW block to the library (only when creating a new section type)

Do this only when the user wants a **completely new** component that is NOT in `sections/`:

1. Create `src/components/sections/SectionName.astro` (props + scoped style).
2. Add an entry in `src/data/sections.ts`: `{ id, name, category, file, demo: {…props…} }`.
3. Done — everything else is automatic and scales to hundreds of blocks: the preview (`preview/[id].astro` auto-resolves the component by `file` via `import.meta.glob`), the copy source (`/raw/<id>` served on demand), the gallery card, category filter, `CATEGORY 01` label, lazy thumbnail and pagination. **Never** edit a component map or import list — just the file + the registry entry.

## Common requests and how to handle them

- "make a lighter / darker version" → use the `variant` prop, don't invert colors by hand.
- "change the main button" → keep `.btn--primary` (indigo), secondary = `.btn--ghost`.
- "add section X to the page" / "I pasted block X's code" → the block is already in `sections/`; do NOT create a duplicate and do NOT touch the gallery — import and insert `<X {...} />` in `src/pages/index.astro` (see "Building the user's page").
- "add a COMPLETELY NEW block type to the library" → copy the pattern from `src/components/sections/`, add it to the registry (see "Adding a COMPLETELY NEW block").
- "add an entrance animation" → `IntersectionObserver` + the `.reveal` class + a reduced-motion guard.
- "change the color to …" → if a token fits, use the token; hardcode only when the user gives a specific hex.

## What NOT to do

- Don't hardcode random colors — reach for the tokens.
- Don't swap Inter for another display font (unless the user explicitly asks).
- Don't remove the `prefers-reduced-motion` guards.
- Don't use the em-dash `—` (it should be `–`).
- Don't make a "generic AI look" — keep to the system: light background, indigo accent, clean Inter, lots of breathing room.
