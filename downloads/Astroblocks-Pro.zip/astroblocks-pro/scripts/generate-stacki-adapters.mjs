import { transform } from 'esbuild';
import { mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const registryFile = path.join(root, 'src/data/sections.ts');
const outputDir = path.join(root, 'src/components/stacki');
const manifestFile = path.join(outputDir, 'manifest.json');

const source = await readFile(registryFile, 'utf8');
const compiled = await transform(source, {
  loader: 'ts',
  format: 'esm',
  target: 'es2022',
});
const dataUrl = `data:text/javascript;base64,${Buffer.from(compiled.code).toString('base64')}`;
const { registry } = await import(dataUrl);

const pad = (value) => String(value).padStart(2, '0');
const pascal = (value) =>
  String(value)
    .replace(/[^a-zA-Z0-9]+(.)/g, (_, char) => char.toUpperCase())
    .replace(/^./, (char) => char.toUpperCase());
const singular = (value) => {
  const word = String(value);
  if (/ies$/i.test(word)) return word.slice(0, -3) + 'y';
  if (/sses$/i.test(word)) return word.slice(0, -2);
  if (/s$/i.test(word) && !/ss$/i.test(word)) return word.slice(0, -1);
  return word;
};
const alpha = (index) => {
  let value = index + 1;
  let result = '';
  while (value > 0) {
    value -= 1;
    result = String.fromCharCode(65 + (value % 26)) + result;
    value = Math.floor(value / 26);
  }
  return result;
};
const joinName = (parts) =>
  parts
    .filter(Boolean)
    .map((part, index) => (index === 0 ? String(part) : pascal(part)))
    .join('');

function scalarType(value) {
  if (typeof value === 'number') return 'number';
  if (typeof value === 'boolean') return 'boolean';
  return 'string';
}

function defaultLiteral(value) {
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  if (value == null) return "''";
  return JSON.stringify(String(value));
}

function addMissingAltFields(value, source) {
  if (Array.isArray(value)) return value.map((item) => addMissingAltFields(item, source));
  if (!value || typeof value !== 'object') return value;

  const next = Object.fromEntries(
    Object.entries(value).map(([key, child]) => [key, addMissingAltFields(child, source)])
  );
  if ('image' in next && !('imageAlt' in next) && /\bimageAlt\b/.test(source)) {
    next.imageAlt = '';
  }
  if (Array.isArray(next.images)) {
    if (!('imageAlts' in next) && /\bimageAlts\b/.test(source)) {
      next.imageAlts = next.images.map(() => '');
    } else if (!('imageAlt' in next) && /\bimageAlt\b/.test(source)) {
      next.imageAlt = next.images.map(() => '');
    }
  }
  return next;
}

function flattenDemo(demo) {
  const fields = [];
  const names = new Set();

  const addLeaf = (parts, value) => {
    let name = joinName(parts) || 'value';
    const base = name;
    let suffix = 2;
    while (names.has(name)) name = `${base}${pad(suffix++)}`;
    names.add(name);
    fields.push({ name, type: scalarType(value), value });
    return name;
  };

  const walk = (value, parts = [], parentArray = false) => {
    if (Array.isArray(value)) {
      return `[${value
        .map((item, index) => {
          const base = singular(parts.at(-1) || 'item');
          const prefix = parts.slice(0, -1);
          const token =
            parentArray || (item != null && typeof item === 'object')
              ? `${base}${pad(index + 1)}`
              : `${base}${pad(index + 1)}`;
          return walk(item, [...prefix, token], true);
        })
        .join(', ')}]`;
    }
    if (value && typeof value === 'object') {
      return `{ ${Object.entries(value)
        .map(([key, child]) => `${JSON.stringify(key)}: ${walk(child, [...parts, key], false)}`)
        .join(', ')} }`;
    }
    const normalizedParts = [...parts];
    if (parentArray && normalizedParts.length >= 2) {
      const last = normalizedParts.at(-1);
      const match = String(last).match(/^(.*?)(\d{2})$/);
      if (match) normalizedParts[normalizedParts.length - 1] = `${match[1]}${match[2]}`;
    }
    return addLeaf(normalizedParts, value);
  };

  // Arrays nested inside a numbered record read better as Image A / Image B
  // than Image 01 / Image 02. Re-run those paths with letter suffixes.
  const walkFriendly = (value, parts = []) => {
    if (Array.isArray(value)) {
      const recordPrefix = parts.some((part) => /\d{2}$/.test(String(part)));
      const base = singular(parts.at(-1) || 'item');
      const prefix = parts.slice(0, -1);
      return `[${value
        .map((item, index) => {
          const suffix = recordPrefix ? alpha(index) : pad(index + 1);
          return walkFriendly(item, [...prefix, `${base}${suffix}`]);
        })
        .join(', ')}]`;
    }
    if (value && typeof value === 'object') {
      return `{ ${Object.entries(value)
        .map(([key, child]) => {
          const numberedParent = parts.some((part) => /\d{2}$/.test(String(part)));
          const friendlyKey =
            numberedParent && /^imageAlts?$/i.test(key) ? 'alt' : key;
          return `${JSON.stringify(key)}: ${walkFriendly(child, [...parts, friendlyKey])}`;
        })
        .join(', ')} }`;
    }
    return addLeaf(parts, value);
  };

  const expression = `{ ${Object.entries(demo)
    .map(([key, value]) => `${JSON.stringify(key)}: ${walkFriendly(value, [key])}`)
    .join(', ')} }`;
  return { fields, expression };
}

await rm(outputDir, { recursive: true, force: true });
await mkdir(outputDir, { recursive: true });

const categoryCounters = new Map();
const manifest = [];

for (const entry of registry) {
  const category = pascal(entry.category);
  const number = (categoryCounters.get(category) || 0) + 1;
  categoryCounters.set(category, number);

  const componentName = `AB${category}${pad(number)}`;
  const fileName = `${componentName}.astro`;
  const originalSource = await readFile(
    path.join(root, 'src/components/sections', entry.file),
    'utf8'
  );
  const editableDemo = addMissingAltFields(entry.demo || {}, originalSource);
  const { fields, expression } = flattenDemo(editableDemo);
  const propLines = fields.map((field) => `  ${field.name}?: ${field.type};`).join('\n');
  const destructureLines = fields
    .map((field) => `  ${field.name} = ${defaultLiteral(field.value)},`)
    .join('\n');

  const adapter = `---
// Generated by scripts/generate-stacki-adapters.mjs.
// Source block: ${entry.category} ${pad(number)} — ${entry.file}
// Regenerate after changing src/data/sections.ts; do not edit this file by hand.
import OriginalComponent from '../sections/${entry.file}';

interface Props {
${propLines}
}

const {
${destructureLines}
} = Astro.props;

const componentProps = ${expression};
---

<OriginalComponent {...componentProps} />
`;

  await writeFile(path.join(outputDir, fileName), adapter);
  manifest.push({
    id: entry.id,
    name: entry.name,
    category: entry.category,
    number,
    component: componentName,
    file: fileName,
    source: entry.file,
    fields: fields.map((field) => field.name),
  });
}

await writeFile(manifestFile, `${JSON.stringify(manifest, null, 2)}\n`);

// Desktop/iCloud folders can briefly restore conflict copies while a generated
// directory is being replaced (for example "ABHero01 2.astro"). Keep only
// the exact files named by the manifest.
const expectedFiles = new Set(['manifest.json', ...manifest.map((entry) => entry.file)]);
for (const file of await readdir(outputDir)) {
  if (!expectedFiles.has(file)) {
    await rm(path.join(outputDir, file), { recursive: true, force: true });
  }
}

console.log(`Generated ${manifest.length} Stacki adapters in ${outputDir}`);
