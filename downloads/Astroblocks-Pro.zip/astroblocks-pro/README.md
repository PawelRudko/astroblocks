# Astroblocks Pro

311 ready-made Astro section blocks built on a single, clean design system. Assemble
landing pages, marketing sites and portfolios in minutes – copy a block, pass a few
props, and ship.

## The 4 steps

1. **Start it** – `npm install && npm run dev`.
2. **Browse the gallery** – open `/blocks`. Every one of the 311 blocks renders live, and
   what you see is exactly the code you get.
3. **Copy the block you want** – one click. You get the component source only, with no
   demo data and no photos attached.
4. **Build your page by chatting** – open this folder in Claude Code, Codex or Cursor and
   say what you want. Use the prompt on the home page, or just:
   *"Read AGENTS.md and add the HeroSplit block to my page, then put an FAQ below it."*

## Quick start

**Requires Node 22.12 or newer** (Astro 7's requirement – Node 20 is end-of-life).
Check yours with `node -v`; if it is older, `nvm install 22 && nvm use 22` or grab the
LTS from [nodejs.org](https://nodejs.org).

```bash
npm install
npm run dev
```

Then open the URL printed in the terminal (http://localhost:4322 by default). To create a
production build:

```bash
npm run build
```

## What's inside

- **311 blocks** in `src/components/sections/` – heroes, navs, features, cards, tabs, CTA,
  pricing, blogs, testimonials, logos, tables, footers and more. Each is a single,
  self-contained `.astro` file with scoped styles and no shared dependencies.
- **311 Stacki adapters** in `src/components/stacki/` – the same blocks with flat,
  editor-friendly fields such as `Card 01 Title`, `Card 01 Image A`, `Card 01 Alt A`
  and `Button 01 URL`. They are generated from the gallery data, not maintained as
  separate visual copies.
- **A live gallery** at `/blocks` – browse, filter by category, preview and copy any block.
- **A blank canvas** at `src/pages/index.astro` – this is your page. Blocks stack inside
  `<main>`.
- **A shared design system** in `src/layouts/Layout.astro` – design tokens, fonts and
  the global `.btn` / `.wrap` / `.eyebrow` helpers that keep every block consistent.
- **`AGENTS.md`** – the kit's brain: tokens, typography, the button system, code
  conventions and how to add sections, written for an AI agent to follow. `CLAUDE.md`
  points Claude Code at it, Codex reads `AGENTS.md` directly, and Cursor can be pointed
  at the same file.

## How to use a block

1. Open `src/components/sections/` and pick a block (or copy it from `/blocks`).
2. Copy the `.astro` file into your own project (or import it directly in a page here).
3. Import it and pass props:

   ```astro
   ---
   import HeroCentered from '../components/sections/HeroCentered.astro';
   ---

   <HeroCentered
     eyebrow="New"
     title="Build calm, considered pages"
     subtitle="A few props and you're done."
     primary={{ label: 'Get started', href: '/signup' }}
   />
   ```

Blocks are fully self-contained – none of them import shared components, so a copied
block works on its own.

## Visual editing in Stacki for Astroblocks

Open this project in Stacki for Astroblocks and use the generated components from
`src/components/stacki/`. Their names follow the gallery numbering: `ABHero01`,
`ABFeatures78`, `ABCard22`, and so on. Inside the editor they are displayed as
`HERO 01`, `FEATURES 78`, `CARD 22`.

The adapters rebuild nested Astro props from clearly named flat controls. For example,
the original `cards={[...]}` API becomes separate `Card 01 Title`, `Card 01 Text`,
`Card 01 Image A` and `Card 01 Alt A` fields. The original components in
`src/components/sections/` remain unchanged and portable.

After editing `src/data/sections.ts`, regenerate this layer with:

```bash
npm run stacki:generate
```

## Images

Blocks never hardcode a photo. Images always come in through a prop, defaulting to the
bundled placeholder `/placeholder-landscape.svg`. Pass your own to replace it:

```astro
<HeroCentered title="…" image="/my-photo.jpg" imageAlt="Description" />
```

Drop your assets in `public/` and reference them with an absolute path. The photos in the
gallery are remote demo URLs that live only in `src/data/sections.ts` – they never travel
with a copied block.

## Design tokens

All tokens – colors, spacing, radii, the type scale and the button styles – live in
`src/layouts/Layout.astro`. Edit them there once and every block updates. `AGENTS.md`
lists them so an agent reaches for a token instead of inventing a value.

## Customizing

The brand name, copy and demo content in the blocks are placeholder examples – replace
them with your own. Everything is plain Astro and CSS, so you can change anything by
hand or ask an AI agent to do it for you.

## License

See `LICENSE-PRO.md`.
