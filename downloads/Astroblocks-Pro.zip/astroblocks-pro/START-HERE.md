# Astroblocks Pro + Stacki for Astroblocks

This package contains the complete Astroblocks Pro project with 311 production-ready Astro blocks and the Stacki for Astroblocks macOS app.

## Start here

1. Open `Stacki for Astroblocks-0.1.3-ab.18-universal.dmg` and drag Stacki for Astroblocks to Applications.
2. If macOS blocks the first launch, Control-click the app, choose **Open**, then confirm **Open**.
3. Open the `Project` folder in Stacki for Astroblocks to browse and add the bundled blocks visually.
4. To run the project directly, install Node.js 22.12 or newer, then run `npm install` and `npm run dev` inside `Project`.

The project remains ordinary Astro code. You can edit it in Stacki, your code editor, or with a coding agent without exporting or moving it to a proprietary runtime.

For product updates and documentation, visit [astroblocks.co](https://astroblocks.co).
