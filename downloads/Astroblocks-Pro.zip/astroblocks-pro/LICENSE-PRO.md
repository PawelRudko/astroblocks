# Astroblocks Pro – Commercial License

Thank you for purchasing Astroblocks Pro. This is a one-time purchase that includes
lifetime updates.

## What you can do

- Use the blocks and design system in **unlimited personal projects**.
- Use them in **unlimited client projects** – build and deliver websites for as many
  clients as you like.
- **Modify the blocks freely** – change the code, styles, structure and content to fit
  each project.
- Ship the results commercially, including in paid products and client work.

## What you can't do

- **Do not redistribute, resell, or republish** the kit or its source code – in whole
  or in part – as a competing product, template, theme, boilerplate or block library.
- Do not share your copy of the kit with people who have not purchased a license.
- Do not present the kit itself (as opposed to a website you build with it) as your own
  product for sale or giveaway.

In short: build as many websites as you want with it – just don't sell the kit itself.

## Terms

- **One-time purchase, lifetime updates.** Your license does not expire, and future
  updates to the kit are included.
- The kit is provided "as is", without warranty of any kind. The author is not liable
  for any damages arising from its use.

© Astroblocks
