# Astroblocks

Astroblocks is a free library of ready-made Astro sections. Every block is available
to preview and copy on the website, and the complete project can be downloaded as a ZIP.

This repository contains the marketing site and the complete block library.

- `/` — the marketing landing (hero, "Three steps", block teaser, manifesto, starter CTA, newsletter).
- `/blocks` — the block gallery (browse + copy), same as the kit.
- `/preview/[id]` — per-block previews.

## Run locally

**Requires Node 22.12 or newer** – Astro 7's requirement. Netlify is pinned to 22 in
`netlify.toml`; leaving it at 20 makes the build fail while the site quietly keeps
serving the previous deploy.

```bash
npm install
npm run dev
```

## Deploy on Netlify

Static build, `netlify.toml` is included.

- **From Git:** create a *private* repo, push this folder, connect it in Netlify. Build command
  `npm run build`, publish dir `dist` (already set in `netlify.toml`).
- **Drag & drop:** run `npm run build`, then drop the `dist/` folder into Netlify.

Then add your custom domain in Netlify → Domain settings.

## Notes

- The design system (tokens, H1–H6, buttons) lives in `src/layouts/Layout.astro`; conventions in `AGENTS.md`.
- The newsletter form is a demo — wire it to MailerLite/Supabase before launch.
- Keep this repo private; the free downloadable kit is public and lives elsewhere.
