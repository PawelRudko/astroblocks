---
name: container-width
description: Block container width is the global --maxw token (1440px); new block wraps must use it
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 37b28da6-d47d-478e-a0cd-2999765036a6
---

The kit's container/wrap width is a **global token `--maxw`**, set to **1440px** in `Layout.astro` (`:root`). The global `.wrap` uses `max-width: var(--maxw)`.

**Every block's `*__wrap` container must use `max-width: var(--maxw, 1440px)`** — the token for central control, the `1440px` fallback so a copied block still has the right width outside the kit. Do NOT hardcode `1200px`/`1280px` in wraps anymore.

**Why:** The user asked to standardize all blocks to a 1440px container and control it globally ("to musi być zawsze w naszym container 1440px … możesz to zmienić globalnie?"). On 2026-07-14 all ~111 block wraps in both `astroblocks-landing` and `astroblocks-pro` were migrated from hardcoded 1200/1280 to `var(--maxw, 1440px)`, and `--maxw` was bumped 1280→1440.

**How to apply:** New block → wrap = `max-width: var(--maxw, 1440px); margin-inline: auto; padding-inline: clamp(1.25rem, 4vw, 2.5rem);`. To change the site-wide width later, edit `--maxw` in Layout only. See [[where-new-blocks-go]].
