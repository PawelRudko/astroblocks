# Astroblocks — stan projektu

Ostatnia aktualizacja: **18 lipca 2026**

Ten plik leży obok obu repozytoriów i **nie jest commitowany** — to notatnik stanu, nie dokumentacja produktu.

---

## Gdzie co leży

| Co | Ścieżka / adres |
|---|---|
| Landing (strona publiczna) | `astroblocks-landing/` → `PawelRudko/astroblocks-landing` → **astroblocks.co** (Netlify) |
| Kit Pro (to, co kupuje klient) | `astroblocks-pro/astroblocks-pro/` → `PawelRudko/astroblocks-pro` |
| Skrypt budujący ZIP | `astroblocks-pro/make-pro-zip.sh` |
| Publiczne repo (30 darmowych bloków) | `PawelRudko/astroblocks` — **NIE dotykać, zostaje jak jest** |
| Produkt | `gumroad.com/products/vyffvw/edit` |

---

## Stan na dziś

- **228 bloków** w obu repo (identyczne), oba wypchnięte, zero niezacommitowanych zmian
- **Astro 7.1.1** wszędzie, także na produkcji
- **ZIP v1.9.0** — `~/Desktop/astroblocks-pro-v1.9.0.zip`, wgrany na Gumroada
- Blog z 3 postami + pełna infrastruktura SEO — live
- Własne IP wyłączone z Google Analytics

---

## Zasady, których trzymamy się przy blokach

1. **Nowe wpisy na KOŃCU swojej kategorii** w `src/data/sections.ts`.
   Etykiety (`FEATURES 16`) liczą się z **pozycji**, więc wpis w środku przenumerowuje wszystko poniżej.
   *(Raz się to zdarzyło — `faq-minimal` przeskoczył z FAQ 06 na 07.)*
2. **Do obu repo**: landing z `tier: 'pro'`, kit **bez** `tier` (w paczce wszystko odblokowane).
3. **Sprawdzać w przeglądarce**, nie tylko `npm run build`.
4. Container: `max-width: var(--maxw, 1440px)`. Przyciski: `.btn--primary` / `.btn--secondary` / `.btn--link`.
5. Zdjęcia **przez propsy** z placeholderem — skopiowany blok nie ciągnie cudzej fotki.
6. Jeden komponent może obsługiwać **kilka wpisów** w rejestrze (np. `ResourceCards` = CARD 18 + BLOG 09).

---

## Co zrobiliśmy 18.07.2026

### Aktualizacja Astro 5.18.2 → 7.1.1
- Testowana najpierw na kopii, dopiero potem na repo
- **Dwa regresy znalezione i naprawione:**
  - `compressHTML` w v7 usuwa spacje między elementami inline → w NavBarze tekst sklejał się w warstwie tekstu („NEWNorthwind… pipelines.Read"). Naprawione jawnymi `{' '}`, **nie** przełącznikiem w configu — bo klient kopiuje bloki do projektów bez naszej konfiguracji.
  - Plakietka „Built with Astro vX" zniknęła (ręczna ścieżka do `node_modules` przestała się rozwiązywać, a `try/catch` połknął błąd). Teraz przez `createRequire`.
- **Netlify miało przypięty Node 20**, a Astro 7 wymaga ≥22.12 → deploy cicho padał, strona serwowała starą wersję. Podbite na 22.

### Blog + SEO (od zera)
- `/blog` + 3 posty: `/blog/astro-components`, `/blog/astro-blocks`, `/blog/astro-landing-page-template`
- Dane w `src/data/posts.ts` — dodanie posta = dopisanie wpisu
- **Brakowało wszystkiego:** sitemapy, robots.txt, `site` w configu, a przez to canonicali. Wszystko dodane.
- Sitemapa napisana ręcznie (bez integracji — projekt ma ich zero i dzięki temu skok na Astro 7 był bezbolesny)
- `robots.txt` blokuje `/preview/` i `/raw/` — 456 stron maszynowych zjadłoby budżet indeksowania
- JSON-LD Article na każdym poście, `head` slot w Layoucie
- Sitemapa zgłoszona do Google Search Console

### Gumroad
- Opis przepisany na kroki 1–4, liczby zaktualizowane na 228
- Nazwa: **`Astroblocks Pro — 228 Astro blocks & UI components`** (slug został `astroblocks-pro`, checkout działa)
- Kategoria: `Other` → **`Design > UI & Web > HTML`**
- Cover + thumbnail zregenerowane (pokazują liczbę bloków i wersję Astro, więc starzeją się co wydanie)

### Google Analytics
- Domowe IP wyłączone z pomiarów, filtr **Aktywny** (konkretny adres — patrz pamięć Claude'a, celowo nie w repo)

---

## Do zrobienia

| Priorytet | Co |
|---|---|
| ⬜ Twoje | **Tagi na Gumroadzie** (Share → Tags): `astro`, `astro theme`, `astro components`, `ui blocks`, `website template`, `tailwind`, `landing page`, `claude code`. Wpisz ręcznie — autouzupełnianie porywa Enter i raz wstawiło „astrology". |
| ⬜ | **Bloki do 250** (zostały 22). Dopiero wtedy pełna aktualizacja ZIP-a, opisu i elementów strony. |
| ⬜ | **Pierwsza sprzedaż** — odblokowuje Gumroad Discover. Sam sobie nie kupisz, Gumroad blokuje zakup u własnego twórcy. |
| 🔵 opcjonalnie | Grafiki OG dla postów (teraz udostępnienia pokazują kartę tekstową) |

---

## Rzeczy, które łatwo zepsuć

- **Zmiana nazwy produktu na Gumroadzie** — sprawdź, czy slug został `astroblocks-pro`. Jeśli się zmieni, wszystkie przyciski „Unlock $69" na stronie prowadzą donikąd, a strona wygląda zdrowo.
- **Opis na Gumroadzie** — edytor autolinkuje `.md` (bo `.md` to domena Mołdawii). Po każdej edycji sprawdź, czy `AGENTS.md` nie stało się linkiem.
- **IP w Analytics jest dynamiczne** — gdy operator je zmieni, filtr cicho przestaje działać. Adres trzymany poza repo.
- **Po aktualizacji Astro** sprawdzaj wersję na **żywej stronie**, nie tylko lokalnie — nieudany deploy Netlify jest niewidoczny od strony repo.

---

Szczegóły techniczne każdej z tych rzeczy siedzą w pamięci projektu Claude'a
(`MEMORY.md` + notatki) i wczytują się automatycznie w nowej sesji.
