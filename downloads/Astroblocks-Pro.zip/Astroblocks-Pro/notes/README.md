# Notatki projektowe

Robocze notatki o tym, jak ten projekt działa i dlaczego pewne rzeczy są zrobione tak,
a nie inaczej. **Nie są częścią produktu** — nie trafiają do ZIP-a Pro ani na stronę.

| Plik | O czym |
|---|---|
| `00-STAN-PROJEKTU.md` | Aktualny stan, co zrobione, co zostało, na czym łatwo się wyłożyć |
| `01-gdzie-trafiaja-nowe-bloki.md` | Do których repo dodawać bloki i dlaczego kolejność wpisów ma znaczenie |
| `02-naglowki-i-przyciski.md` | Wzorzec nagłówków i przycisków, którego trzymają się wszystkie bloki |
| `03-szerokosc-containera.md` | `--maxw` i dlaczego nie wpisujemy szerokości na sztywno |
| `04-jak-budowac-zip.md` | Jak wydać nową wersję paczki Pro |
| `05-aktualizacje-astro.md` | Jak bezpiecznie podnieść Astro + co się zepsuło ostatnio |

**Świadomie NIE ma tu:** adresu IP, NIP-u, danych konta bankowego ani adresów e-mail.
Te siedzą w pamięci Claude'a i nie ma powodu, by leżały w repozytorium — nawet prywatnym,
bo prywatne repo bywa kiedyś współdzielone albo otwierane.
