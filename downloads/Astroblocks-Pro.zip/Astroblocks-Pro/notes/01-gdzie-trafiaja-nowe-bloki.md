---
name: where-new-blocks-go
description: "New blocks go ONLY to astroblocks-landing and astroblocks-pro, never to the public astroblocks repo"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 37b28da6-d47d-478e-a0cd-2999765036a6
---

When building a new block, add it **ONLY** to two places (both now use the SAME structure — gallery + registry):
- **`astroblocks-landing`** — the `.astro` file in `src/components/sections/` **+** a registry entry in `src/data/sections.ts`. (Landing may mark blocks `tier: 'pro'` to lock them in its gallery.)
- **`astroblocks-pro`** — the `.astro` file in `src/components/sections/` **+** a registry entry in `src/data/sections.ts`. **Do NOT add `tier: 'pro'`** here — in the paid kit every block must stay unlocked/copyable.

**NEVER** add new blocks to the public repo **`PawelRudko/astroblocks`** — that is the fixed 30-free kit and "zostaje jak jest" (stays as is).

**Pro kit is now a clean starter (rebuilt 2026-07-13):** same UX as the free kit — blank-canvas `index.astro` ("A blank page. Start building by talking.") + `/blocks` gallery + `/preview` + `/raw` — but with the FULL 114-block library, all unlocked. It is NOT the marketing landing and NOT a stripped demo. Deliverable ZIP built via `astroblocks-pro/make-pro-zip.sh <version>` (latest v1.2.0).

**Why:** The user flagged this as a WAŻNA UWAGA (important rule) on 2026-07-13. The public repo is the free teaser; the paid value lives in landing (full library) and pro (paid ZIP/download). Mixing them up already caused an incident where the landing got pushed to the public repo — see [[project-astroblocks-infra]].

**⚠️ APPEND the registry entry, don't INSERT it mid-file — labels are positional.** `label = CATEGORY + position-within-that-category`, so a new entry slotted before existing ones **renumbers every later block in that category**. This bit us on 2026-07-17: `FaqTabbed` was inserted near the top of the registry and became FAQ 02, silently pushing `faq-categories` 02→03, `faq-centered` 03→04, `faq-images` 04→05, `faq-icon-nav` 05→06 and `faq-minimal` 06→**07**. Claude had already told the user the new block was "FAQ 07" — it wasn't. Anyone who had learned "add FAQ 06" now gets a different block. **Add new entries at the END of their category's run** (or the end of the registry) so existing labels stay put. See [[pro-zip-deliverable]] for how labels are generated.

**One component can serve several registry entries** — register the same `file` under two ids/categories when the pattern honestly belongs to both (e.g. `ResourceCards.astro` = CARD 18 + BLOG 09; `FaqTabbed.astro` = FAQ 02 + TABS 06). Don't duplicate the .astro file.

**How to apply:** Also documented at the top of both repos' `README.md`. Follow [[heading-button-structure]] for the block's markup pattern.
