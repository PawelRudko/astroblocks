---
name: astro-version-upgrades
description: "How to upgrade Astro across astroblocks-landing + astroblocks-pro, and what broke last time"
metadata: 
  node_type: memory
  type: project
  originSessionId: e18a2aa0-d1ae-4d87-a39e-df7653e3d299
---

**Both repos run Astro 7.1.1 as of 2026-07-18** (upgraded from 5.18.2, two majors in one step). `package.json` now carries `^7.1.1` in both.

**Why upgrades are cheap here:** across 211 block files the kit uses exactly **three** Astro features — `Astro.props`, `class:list`, `set:html` — plus **zero** `@astrojs/*` integrations, no adapter, no framework renderer, no experimental flags. The only heavier API is the gallery scaffolding: `import.meta.glob`, `getStaticPaths`, `APIRoute`, `?raw` in `src/pages/preview/[id].astro` and `src/pages/raw/[id].ts`. Major-version breakage usually lands on integrations, images, markdown and i18n — none of which this project uses.

**Upgrade procedure that worked (repeat it):**
1. Read the official upgrade guides (`docs.astro.build/en/guides/upgrade-to/vN/`) — don't guess at breaking changes.
2. `rsync -a --exclude node_modules --exclude dist --exclude .git` the **kit** to a scratch dir, `npm install astro@latest` there, `npm run build`. Never test on the real repos first.
3. Compare the **visible text layer**, not raw bytes — Astro rewrites scoped-class hashes and asset names every build, so a byte diff shows 100% changed and tells you nothing. Strip tags, collapse whitespace, diff that. Target: 0 differing pages.
4. Only then upgrade both repos, rebuild, check block count (228), `/raw` + `/preview` counts, and that premium `/raw/<pro-id>` still 404s.

**Two regressions the 5→7 jump caused (both fixed, watch for them again):**
- **`compressHTML` default became `'jsx'`** — whitespace between adjacent inline elements is stripped. Visually harmless across this kit because it separates inline things with **flex `gap` or margins**, never with HTML whitespace. But `NavBar.astro`'s announcement bar collapsed in the *text layer*: `"NEWNorthwind … pipelines.Read more"` — margins still drew the gap so it *looked* right while copy-paste and screen readers got run-together words. Fixed with explicit `{' '}` in the source, **not** by setting `compressHTML: true` in config — buyers copy blocks into projects that won't have our config, so blocks must not depend on it.
- **`blocks.astro`'s "Built with Astro vX" badge silently vanished** — it read `../../node_modules/astro/package.json` via a hand-written relative path, that stopped resolving under the v7 build, and the `try/catch` swallowed the error so the badge just disappeared. Now uses `createRequire(import.meta.url)('astro/package.json').version`. **A silent `catch` around a version lookup hides exactly this** — if the badge is ever blank, suspect resolution, not the version.

**Node:** Astro 6+ needs **≥ 22.12.0**. The Mac is on v24, fine — but **`astroblocks-landing/netlify.toml` pinned `NODE_VERSION = "20"`**, so the first deploy after the upgrade failed and **Netlify silently kept serving the previous build**: the repo said 7.1.1 while astroblocks.co still reported Astro v5.18.2 and looked completely healthy. Bumped to `"22"`. **After any major upgrade, check the live site's version badge, not just the local build** — a failed Netlify deploy is invisible from the repo side.

**Cadence:** `npm outdated` about quarterly. Note `^5.x`-style ranges never cross a major, so `npm update` alone will silently keep you behind — check `npm view astro version` against the installed one. Astro 7 also builds ~2.5× faster than 5 (Rust compiler).

Related: [[pro-zip-deliverable]], [[where-new-blocks-go]]
