---
name: heading-button-structure
description: Always reuse the established heading + button structure from existing blocks when building new ones
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 37b28da6-d47d-478e-a0cd-2999765036a6
---

When building new blocks (Hero, Blog, etc.), keep the SAME heading and button structure as the existing blocks — do not invent new heading/button patterns per block. Reference pattern is Hero 12 = `HeroLeadMedia.astro`: three-part nav (brand left · center links · Contact right), overline beside a heading with a muted (`--faint`) tail, and buttons using the global classes `.btn--secondary` (primary action) + `.btn--link` (secondary action).

**Why:** The user explicitly praised this consistency ("trzymaj się zawsze tej samej struktury nagłówków i przycisków tak jak poprzednie block – jest super"). Consistency across blocks is the point of the design system in AGENTS.md.

**How to apply:** Before adding a new section, look at the closest existing block and mirror its nav/overline/heading/button markup and classes. Use tokens and the global button classes; never hardcode a bespoke heading or button style. See [[project-astroblocks-infra]] for where blocks live.
