---
name: pro-zip-deliverable
description: "IMPORTANT — how to make the Astroblocks Pro ZIP for download / Lemon Squeezy upload, and where it lives"
metadata: 
  node_type: memory
  type: project
  originSessionId: 37b28da6-d47d-478e-a0cd-2999765036a6
---

**⭐ VERY IMPORTANT (user flagged) — the Pro deliverable ZIP.**

The paying customer downloads a ZIP (uploaded to lemonsqueezy.com). It must be the **clean starter kit**: blank-canvas `index.astro` + `/blocks` gallery + full 114-block library, all unlocked — NOT the marketing landing, NOT a stripped demo.

**How to (re)generate the ZIP** — one command, in `~/Desktop/Codex Claude Web/astroblocks-pro/`:
```
./make-pro-zip.sh <version>      # e.g. ./make-pro-zip.sh 1.6.0
```
It builds `astroblocks-pro-v<version>.zip` (top folder `astroblocks-pro/`, excludes node_modules/dist/.git) and prints the block count + a junk check. Verify with `unzip -tq <file>` (expect "No errors").

**Locations of the current ZIP (v1.9.0, 534KB, 211 block files / 228 registry entries, on Astro 7.1.1, verified OK 2026-07-18):**
- Canonical: `~/Desktop/Codex Claude Web/astroblocks-pro/astroblocks-pro-v1.9.0.zip`
- Easy-access copy on Desktop root: `~/Desktop/astroblocks-pro-v1.9.0.zip` (make this copy manually — the script only writes the canonical one)
- **v1.9.0 is LIVE on Gumroad since 2026-07-18** (user uploaded it; product page reports 534 KB). Verified the buyer path end-to-end: fresh unzip → `npm install` → `npm run build` → 230 pages, zero errors.
- **Release checklist that worked:** push both repos → confirm Netlify actually deployed (check the live version badge, see [[astro-version-upgrades]]) → refresh block counts in the kit's `README.md` and the category list in `AGENTS.md` → `./make-pro-zip.sh <ver>` → test the ZIP from scratch → user uploads → update the Gumroad description → **regenerate cover + thumbnail** (they show the block count and Astro version, so they go stale on every release).
(Older versions v1.0–v1.8.0 superseded. Bump the version each release — **never rebuild an already-tested version number with different contents**. **v1.8.1 is LIVE on Gumroad since 2026-07-17** — uploaded and verified: Content holds only v1.8.1, and the public product page reports "Size 502 KB".)

**v1.8.1 — label matching must be tolerant.** The user works in **Polish and English interchangeably** ("dodaj mi blok Hero 01", "wstaw Features 02 pod spodem", "Add Features 05") and types labels rather than quoting them. AGENTS.md now requires: any case, optional zero-padding (`Hero 1` = `HERO 01`), obvious singular/plural (`Feature` → `Features`), request in **any language** with the label never translated, and reply in the user's language. **`Subpage Hero` is the only two-word category** of the 18 — `SUBPAGE HERO 03` breaks naive "word + number" parsing. (Careful when counting categories: grepping `category: '…'` also hits **demo data** inside blog/card blocks — match `id`+`name`+`category`+`file` adjacency to get only the 18 real registry categories.)

**⭐ DON'T NAG ABOUT THE ZIP UNTIL 250 BLOCKS (user's call, 2026-07-17).** The site's registry keeps growing (219 as of 2026-07-17) while Gumroad still serves **v1.8.1 = 210 blocks**, and the product description says "210". The user knows and decided: **at 250 blocks he'll do one update pass — rebuild the ZIP, refresh the description count, and update the site's elements together.** So keep adding blocks to both repos and stop flagging the drift on every turn; raise it again when the count reaches ~250.

**Adding a NEW category is just a registry field** — the chip row is derived from `[...new Set(registry.map(s => s.category))]`, so a new `category:` value creates its own chip and `CATEGORY 01` label automatically, no gallery code to touch. Chip order = order of first appearance in the registry, so place the entry next to related categories (e.g. `Blog Details` was added right after the `Blog` run, 2026-07-18). Multi-word categories work — `Blog Details` → `BLOG DETAILS 01`.

**⚠️ Gallery labels (`FEATURES 16`, `HERO 03`) exist in NO file** — `src/data/sections.ts` generates them at the bottom: `label = CATEGORY + position-within-that-category` (1-based, registry order). So "add FEATURES 16" makes an agent grep for a string with zero hits, then guess. v1.8.0 added an AGENTS.md section ("Finding a block the user names from the gallery") telling it to **count**, not search, and that `id`/`name` are the real handles. `FEATURES 16` = `feature-services-images` / `FeatureServicesImages.astro` (cross-checked). The kit's `/blocks` subhead now also tells the buyer both routes work: Copy button, or name the block while chatting.

**The kit is NOT the landing — don't confuse them when debugging.** Both have a `/blocks` gallery and both default to port **4322**. The paid kit has **no "Unlock $69" and no PREMIUM badge at all** (0 occurrences — `Gallery.astro` doesn't know those words); if you see them, you're looking at `astroblocks-landing` or astroblocks.co. Tell them apart by `/`: kit = blank canvas ("A blank page. Start building by talking."), landing = marketing page. v1.8.0 also removed landing copy that had leaked into the paid kit's gallery ("Free Astro blocks." on a page the customer paid for).

**⚠️ v1.7.0 fixed a real defect — do not regress it.** v1.6.0 (the ZIP sold at launch) shipped WITHOUT `AGENTS.md`/`CLAUDE.md`, even though **179 block files say "see AGENTS.md"** and the blank canvas's "Copy starter prompt" button opens with *"Read AGENTS.md"*. So the buyer's very first action pointed an agent at a file that wasn't there. Both files live in the **landing** repo and are landing-neutral — v1.7.0 copies them across 1:1. `make-pro-zip.sh` now **hard-fails** if AGENTS.md/CLAUDE.md/README.md are missing from the archive.
- Gotcha when editing that guard: `unzip -l "$OUT" | grep -q …` **fails under `set -o pipefail`** — grep closes the pipe, unzip takes SIGPIPE, pipeline reports failure even when the file IS present. List once into a variable, then grep the variable.
- v1.7.0 also: README said "110+ blocks" (it's 210) and never mentioned the `/blocks` gallery; dropped a dead `CHECKOUT_URL` still holding the retired Lemon Squeezy test link; removed an empty stray `src/components/sections 2` folder that was being shipped.

**Then:** upload that ZIP in the **Content** tab of the Gumroad product (`gumroad.com/products/vyffvw/edit`) and hit Save changes — **the user must click the upload themselves**, Claude's file_upload is path-sandboxed. User does this occasionally ("raz na jakiś czas") whenever blocks change — bump the version each time. v1.6.0 is what's live on Gumroad since 2026-07-17.

Source of the kit = `astroblocks-pro/astroblocks-pro/` (private repo `PawelRudko/astroblocks-pro`). See [[project-gumroad-checkout]], [[where-new-blocks-go]], [[project-astroblocks-infra]].
