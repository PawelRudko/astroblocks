// Hand-rolled sitemap. @astrojs/sitemap would also work, but this project deliberately ships
// zero integrations (see the Astro 7 upgrade — that's why it was painless), and the whole
// thing is fifteen lines.
//
// Deliberately excluded: /preview/* and /raw/* — 456 near-duplicate pages that would drown the
// pages that actually matter and dilute the crawl budget on a new domain.
import type { APIRoute } from 'astro';
import { posts } from '../data/posts';

const SITE = 'https://astroblocks.co';

type Entry = { path: string; changefreq: string; priority: string; lastmod?: string };

const staticPages: Entry[] = [
  { path: '/', changefreq: 'weekly', priority: '1.0' },
  { path: '/blocks', changefreq: 'weekly', priority: '0.9' },
  { path: '/astro-components', changefreq: 'weekly', priority: '0.9' },
  { path: '/docs', changefreq: 'monthly', priority: '0.8' },
  { path: '/blog', changefreq: 'weekly', priority: '0.8' },
  { path: '/privacy', changefreq: 'yearly', priority: '0.2' },
];

// Astro's canonical URLs end in a slash. The sitemap has to list the *same* form, or Google
// follows /blocks from here and finds a page declaring /blocks/ as canonical — a mixed signal
// that slows indexing on a young domain.
const withSlash = (p: string) => (p === '/' || p.endsWith('/') ? p : `${p}/`);

export const GET: APIRoute = () => {
  const entries: Entry[] = [
    ...staticPages,
    ...posts.map((p) => ({
      path: `/blog/${p.slug}`,
      changefreq: 'monthly',
      priority: '0.7',
      lastmod: p.iso,
    })),
  ].map((e) => ({ ...e, path: withSlash(e.path) }));

  const body = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${entries
  .map(
    (e) => `  <url>
    <loc>${SITE}${e.path}</loc>${e.lastmod ? `\n    <lastmod>${e.lastmod}</lastmod>` : ''}
    <changefreq>${e.changefreq}</changefreq>
    <priority>${e.priority}</priority>
  </url>`
  )
  .join('\n')}
</urlset>`;

  return new Response(body, {
    headers: { 'content-type': 'application/xml; charset=utf-8' },
  });
};
