// Blog posts. Same shape as the BlogDetail block's props, so /blog/<slug> renders through the
// kit's own component — the library eats its own dog food.
// Adding a post = adding an entry here. The index page and /blog/<slug> follow automatically.

export interface Piece { type: 'h2' | 'p' | 'quote' | 'code'; text: string }

export interface Post {
  slug: string;
  title: string;          // <h1> and <title>
  seoTitle?: string;      // overrides <title> when the headline reads badly in a SERP
  description: string;    // meta description — keep under ~155 chars
  lede: string;
  date: string;           // display
  iso: string;            // machine-readable, for <time> and the sitemap
  readTime: string;
  category: string;
  body: Piece[];
}

export const posts: Post[] = [
  {
    slug: 'astro-components',
    title: 'Astro components, explained properly',
    seoTitle: 'Astro Components: Props, Scoped Styles and Zero JavaScript',
    description:
      'How .astro components actually work — frontmatter, props, scoped styles, and why almost none of it reaches the browser. With runnable examples.',
    lede:
      'A component that ships no JavaScript sounds like a trick. It is not — it is just a template that runs once, at build time, and then gets out of the way.',
    date: 'July 18, 2026',
    iso: '2026-07-18',
    readTime: '6 min read',
    category: 'Astro',
    body: [
      { type: 'p', text: 'If you arrive at Astro from React or Vue, the first .astro file looks familiar and then quietly refuses to behave like one. There is no useState, no lifecycle, no re-render. That absence is the whole point, and it is worth understanding before you fight it.' },
      { type: 'h2', text: 'A component is a template that runs once' },
      { type: 'p', text: 'An .astro file has two parts: frontmatter between two --- fences, and markup below it. The frontmatter is plain JavaScript that runs on the server during the build. The markup is HTML with expressions. When the build finishes, the frontmatter is gone and what remains is static HTML.' },
      { type: 'code', text: `---
interface Props {
  title: string;
  subtitle?: string;
}
const { title, subtitle } = Astro.props;
---

<section class="hero">
  <h1>{title}</h1>
  {subtitle && <p>{subtitle}</p>}
</section>` },
      { type: 'p', text: 'That is a complete, production-ready component. No imports, no runtime, no hydration. Used on a page, it renders to three lines of HTML and contributes exactly zero bytes of JavaScript.' },
      { type: 'h2', text: 'Props are the only input' },
      { type: 'p', text: 'Astro.props is how content gets in, and typing it with a Props interface is worth the ten seconds. Your editor then autocompletes every prop at the call site, and a typo becomes a build error rather than an empty heading in production.' },
      { type: 'p', text: 'The pattern that scales is to give every prop a sensible default and let the caller override what matters. A block with eight optional props and two required ones is pleasant to reuse; a block with ten required props is a form you have to fill in every time.' },
      { type: 'h2', text: 'Styles are scoped by default' },
      { type: 'p', text: 'A <style> tag inside a component applies only to that component. Astro adds a data attribute to the elements and rewrites your selectors to match, so a .title class in one file cannot leak into another. You get the isolation of CSS modules without importing anything or renaming a class.' },
      { type: 'code', text: `<style>
  .hero { padding: clamp(3rem, 7vw, 6rem) 0; }
  .hero h1 { font-size: clamp(2rem, 5vw, 3rem); }
</style>` },
      { type: 'p', text: 'When you deliberately want to reach outside — a design token, a shared button class — use <style is:global> in a layout, or define the token as a CSS custom property on :root. Keeping a small set of global tokens and scoping everything else is the balance that holds up over hundreds of components.' },
      { type: 'quote', text: 'Scoped by default, global on purpose. That single rule prevents most CSS regressions in a large component set.' },
      { type: 'h2', text: 'When you do need JavaScript' },
      { type: 'p', text: 'A plain <script> tag in an .astro file is bundled and shipped, and it runs once on page load. That is enough for the majority of interface work: toggling a class, switching a tab panel, opening a menu. It is not a framework and does not need to be.' },
      { type: 'code', text: `<script>
  document.querySelectorAll('[data-tabs]').forEach((box) => {
    const tabs = box.querySelectorAll('.tab');
    tabs.forEach((tab) => tab.addEventListener('click', () => {
      tabs.forEach((t) => t.setAttribute('aria-selected', String(t === tab)));
    }));
  });
</script>` },
      { type: 'p', text: 'Reach for a framework component with a client: directive only when you genuinely need reactive state that survives interaction — a live search, a cart, a canvas. Everything above that line is a class toggle wearing a costume.' },
      { type: 'h2', text: 'The trade-off worth naming' },
      { type: 'p', text: 'Astro components cannot re-render. If a value changes after load, you update the DOM yourself or you hydrate an island. For marketing pages, documentation and content sites that constraint costs you almost nothing and buys you a page that is fast before you optimise a single thing.' },
      { type: 'p', text: 'For an app with genuinely reactive state on every screen, the constraint becomes friction. Knowing which of the two you are building is more useful than any benchmark.' },
    ],
  },
  {
    slug: 'astro-blocks',
    title: 'Astro blocks beat a component library',
    seoTitle: 'Astro Blocks: Copy-Paste Sections Instead of a Dependency',
    description:
      'A block is a whole page section you copy into your project and own. Why that beats installing a component library — and what it costs you.',
    lede:
      'A component library gives you a dependency. A block gives you a file. The difference shows up the first time you need something the library did not anticipate.',
    date: 'July 18, 2026',
    iso: '2026-07-18',
    readTime: '5 min read',
    category: 'Astro blocks',
    body: [
      { type: 'p', text: 'Most UI kits ship as a package. You install it, import a Hero, pass props, and accept whatever the author decided a Hero should be. The moment your design calls for something slightly different, you are reading node_modules and writing overrides.' },
      { type: 'p', text: 'A block inverts that. It is a single .astro file you copy into your own components folder. From then on it is your code — you edit it directly, in place, with no wrapper and nothing to override.' },
      { type: 'h2', text: 'What makes a section a block' },
      { type: 'p', text: 'Three properties, and all three matter:' },
      { type: 'p', text: 'It is self-contained. No imports from a shared internal module, no helper file that has to come along. Copy the file and it renders.' },
      { type: 'p', text: 'Its content arrives through props. Nothing is hardcoded into the markup, so the same block serves an architecture studio and a SaaS pricing page without being forked.' },
      { type: 'p', text: 'Its styles are scoped. Dropping it into an existing project cannot break the styles already there, and the project cannot break the block.' },
      { type: 'quote', text: 'If copying one file into an empty project does not render, it was a component, not a block.' },
      { type: 'h2', text: 'Why the copy-paste model wins here' },
      { type: 'p', text: 'The usual objection is duplication: copies drift, and a fix in one place does not reach the others. That is a real cost in application code, where the same logic runs in twenty screens.' },
      { type: 'p', text: 'Page sections are not that. A hero on the homepage and a hero on the pricing page are meant to diverge — different copy, different emphasis, often a different layout by month three. Forcing them to share an abstraction produces a component with nine boolean props and a rendering branch for each, which nobody can safely change.' },
      { type: 'p', text: 'Copies drift, and for marketing sections drifting is the requirement rather than the bug.' },
      { type: 'h2', text: 'Consistency without coupling' },
      { type: 'p', text: 'The obvious risk is a site that looks assembled from parts. The fix is not shared components — it is shared tokens. Put colour, spacing, radii and the type scale in one layout file as CSS custom properties, and have every block read from them.' },
      { type: 'code', text: `:root {
  --text: #21201c;
  --line: rgba(24, 24, 27, 0.1);
  --radius-card: 16px;
  --maxw: 1440px;
}` },
      { type: 'p', text: 'Change --maxw once and every section follows. The blocks stay independent files; only the vocabulary is shared. That is the same separation a design system makes between components and foundations, applied where it actually pays.' },
      { type: 'h2', text: 'Where blocks are the wrong tool' },
      { type: 'p', text: 'They are a poor fit for anything with real logic. A data table with sorting, a multi-step form with validation, an authenticated dashboard widget — those want a genuine component with tests, versioned in one place.' },
      { type: 'p', text: 'Blocks earn their keep on the layer above: the sections a marketing site is made of, where the work is layout and copy rather than behaviour, and where being able to change one page without touching another is worth more than reuse.' },
    ],
  },
  {
    slug: 'astro-landing-page-template',
    title: 'An Astro landing page without a page builder',
    seoTitle: 'Build an Astro Landing Page: A Practical Walkthrough',
    description:
      'From npm create astro to a deployed page: project structure, sections, design tokens, images and hosting. No page builder, no lock-in.',
    lede:
      'Page builders are quick until you want something they did not plan for. This is the other route — a real Astro project you own, start to finish, in about an evening.',
    date: 'July 18, 2026',
    iso: '2026-07-18',
    readTime: '7 min read',
    category: 'Tutorial',
    body: [
      { type: 'p', text: 'The pitch for a page builder is that you avoid code. The bill arrives later: a subscription, an export that produces markup nobody wants to maintain, and a hard stop the first time the design needs something the builder does not offer.' },
      { type: 'p', text: 'A hand-built Astro page takes an evening and leaves you with files you own. Here is the whole path.' },
      { type: 'h2', text: 'Start the project' },
      { type: 'code', text: `npm create astro@latest my-site
cd my-site
npm run dev` },
      { type: 'p', text: 'Choose the empty template. You want a blank canvas, not a demo blog to delete. The dev server prints a local URL and reloads as you save.' },
      { type: 'h2', text: 'Set your tokens before your sections' },
      { type: 'p', text: 'This is the step people skip and regret. Before writing a single section, decide the handful of values every section will read — colours, the type scale, spacing rhythm, corner radius, maximum content width. Put them in your layout as custom properties.' },
      { type: 'code', text: `<style is:global>
  :root {
    --bg: #ffffff;
    --text: #21201c;
    --accent: #5b5bd6;
    --maxw: 1440px;
    --radius-card: 16px;
  }
  body { background: var(--bg); color: var(--text); }
</style>` },
      { type: 'p', text: 'Do this first and a rebrand later is one file. Skip it and it is a search-and-replace across every section you have written, which is how sites end up with four slightly different greys.' },
      { type: 'h2', text: 'Build the page from sections' },
      { type: 'p', text: 'A landing page is a stack: navigation, hero, features, social proof, pricing, FAQ, footer. Give each one its own file in src/components/sections/, then assemble them in src/pages/index.astro.' },
      { type: 'code', text: `---
import Layout from '../layouts/Layout.astro';
import Hero from '../components/sections/Hero.astro';
import Features from '../components/sections/Features.astro';
---

<Layout title="My studio">
  <main>
    <Hero title="We build calm, fast websites" />
    <Features items={[ /* … */ ]} />
  </main>
</Layout>` },
      { type: 'p', text: 'Keep content in props rather than in the markup. It takes no extra effort while you are writing the section and saves you from hunting through HTML when the copy changes — which it will, twice, before launch.' },
      { type: 'h2', text: 'Handle images so they do not rot' },
      { type: 'p', text: 'Never hardcode a photo inside a section. Accept it as a prop and default to a placeholder that ships with the project:' },
      { type: 'code', text: `---
const { image = '/placeholder.svg', imageAlt = '' } = Astro.props;
---
<img src={image} alt={imageAlt} loading="lazy" />` },
      { type: 'p', text: 'Now a section copied into another project renders immediately instead of pointing at a file that does not exist there. Put real files in public/ and reference them with an absolute path.' },
      { type: 'h2', text: 'Deploy it' },
      { type: 'p', text: 'Astro builds to static HTML, so hosting is close to free and close to instant. Push the repo to GitHub and connect it to Netlify, Vercel or Cloudflare Pages; the build command is npm run build and the output directory is dist.' },
      { type: 'p', text: 'One detail worth pinning: set the Node version explicitly in your host config. Recent Astro needs Node 22 or newer, and a host defaulting to an older one fails the build while quietly serving the previous deploy — the site looks fine and your change never appears.' },
      { type: 'h2', text: 'What you end up with' },
      { type: 'p', text: 'Static HTML with almost no JavaScript, hosting you can move in an afternoon, and every file under your control. No subscription, no export step, and no ceiling on what the design can do.' },
      { type: 'p', text: 'The only real cost is the first evening — and unlike the builder route, you only pay it once.' },
    ],
  },
];

export const postBySlug = (slug: string) => posts.find((p) => p.slug === slug);
